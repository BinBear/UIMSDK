//
//  UIMSDK.h
//  UIMSDK
//
//  Created by Retso Huang on 1/11/15.
//  Copyright (c) 2015 Retso Huang. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UIMSDK.
FOUNDATION_EXPORT double UIMSDKVersionNumber;

//! Project version string for UIMSDK.
FOUNDATION_EXPORT const unsigned char UIMSDKVersionString[];

#import <UIMSDK/UIMClient.h>


